import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Stage 0: previously both flags below were `true`, which let `next build`
  // succeed even with type errors and lint violations — silently masking
  // real bugs (e.g. the mock-vs-schema drift fixed in this stage). Both
  // checks now run for real during `next build` / `npm run build`.
  typescript: {
    ignoreBuildErrors: false,
  },
  eslint: {
    ignoreDuringBuilds: false,
  },
};

export default nextConfig;
