import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Personal Operating System",
  description: "A comprehensive SaaS platform to manage your identity, goals, and daily execution.",
};

// Deliberately minimal: this is the ONLY layout shared by both the public
// pages (/login, /signup) and the authenticated app (the "(app)" route
// group below, which has its own layout with the Sidebar + auth check).
// Do not add data fetching or auth-only UI here.
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col overflow-hidden">
        {children}
      </body>
    </html>
  );
}
