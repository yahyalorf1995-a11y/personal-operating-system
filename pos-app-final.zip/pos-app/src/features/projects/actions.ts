"use server";

import { prisma } from "@/lib/db";
import { revalidatePath } from "next/cache";
import type { ProjectStatus } from "@prisma/client";
import { getCurrentIdentity } from "@/lib/current-user";

// Fetch Projects — scoped to the current user
export async function getProjects() {
  const identity = await getCurrentIdentity();
  return prisma.project.findMany({
    where: { lifeArea: { identityId: identity.id } },
    include: { lifeArea: true, goal: true, tasks: true },
    orderBy: { createdAt: "desc" },
  });
}

// Create new Project
export async function createProject(formData: FormData) {
  const title = formData.get("title") as string;
  const description = formData.get("description") as string;
  const lifeAreaId = formData.get("lifeAreaId") as string;
  const goalId = formData.get("goalId") as string;

  if (!title || !lifeAreaId) return;

  const identity = await getCurrentIdentity();
  const ownsLifeArea = await prisma.lifeArea.findFirst({
    where: { id: lifeAreaId, identityId: identity.id },
    select: { id: true },
  });
  if (!ownsLifeArea) return;

  const resolvedGoalId = goalId === "none" || !goalId ? null : goalId;
  if (resolvedGoalId) {
    const ownsGoal = await prisma.goal.findFirst({
      where: { id: resolvedGoalId, lifeArea: { identityId: identity.id } },
      select: { id: true },
    });
    if (!ownsGoal) return;
  }

  await prisma.project.create({
    data: {
      title,
      description,
      lifeAreaId,
      goalId: resolvedGoalId,
      status: "PLANNING",
      progress: 0,
    },
  });

  revalidatePath("/projects");
}

// Update Project Status (only if it belongs to the current user)
export async function updateProjectStatus(formData: FormData) {
  const id = formData.get("id") as string;
  const status = formData.get("status") as ProjectStatus;

  if (!id || !status) return;

  const identity = await getCurrentIdentity();
  await prisma.project.updateMany({
    where: { id, lifeArea: { identityId: identity.id } },
    data: { status },
  });

  revalidatePath("/projects");
}

// Delete Project (only if it belongs to the current user)
export async function deleteProject(formData: FormData) {
  const id = formData.get("id") as string;
  if (!id) return;

  const identity = await getCurrentIdentity();
  await prisma.project.deleteMany({
    where: { id, lifeArea: { identityId: identity.id } },
  });

  revalidatePath("/projects");
}
